const express = require('express');
const app = express();
const morgan = require('morgan');
const users = require('./usuarios');
const jugadores = require('./jugadores');
const fs = require('fs');


var path = require('path');
var publicPath = path.resolve(__dirname, '../../Cliente'); 
app.use(express.static(publicPath));


// Settings
app.set('port', process.env.PORT || 3000);
app.set('json spaces', 2);

// middlewares
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

let usuarioLogueado = ""

//Routes
app.get('/login', (req, res) => {
    res.sendFile(path.resolve(__dirname, '../../Cliente/index.html'));
});

app.post("/login", function (req, res) {
  for (i=0;i<=users.length;i++) {
    console.log(users[i]);
    if (users[i]!=null && users[i].usuario==req.body.usuario.toString() && users[i].password==req.body.password.toString()) {
      user = users[i].usuario;
      usuarioLogueado = user;
      res.json({ user: users[i].usuario});
    }
  }
  res.json({ user: ""});
}   
);

app.post("/figuritas", function (req, res) {

  selec ="";
  if(req.body.dato.toString()==""){
    res.json(jugadores);
  }else{
    let jugadoresFiltrados = [];
    if(req.body.filtro.toString().toLowerCase()=="seleccion"){
      for (i=0;i<=jugadores.length;i++) {
        if (jugadores[i]!=null && jugadores[i].Seleccion.toLowerCase()==req.body.dato.toString().toLowerCase()) {
          jugadoresFiltrados.push(jugadores[i]);
          selec = jugadores[i].Seleccion.toLowerCase();
        }
      }
    }else if(req.body.filtro.toString().toLowerCase()=="region"){
      for (i=0;i<=jugadores.length;i++) {
        if (jugadores[i]!=null && jugadores[i].Region.toLowerCase()==req.body.dato.toString().toLowerCase()) {
          jugadoresFiltrados.push(jugadores[i]);
        }
      }
    }else if(req.body.filtro.toString().toLowerCase()=="nombre"){
      console.log("nombre");
      for (i=0;i<=jugadores.length;i++) {
        if (jugadores[i]!=null && jugadores[i].Jugador.toLowerCase()==req.body.dato.toString().toLowerCase()) {
          console.log(jugadores[i]);
          jugadoresFiltrados.push(jugadores[i]);
        }else if(jugadores[i]!=null && jugadores[i].Apellido.toLowerCase()==req.body.dato.toString().toLowerCase()){
          jugadoresFiltrados.push(jugadores[i]);
        }
      }
    }
    res.json(jugadoresFiltrados);
  }

}   
);




app.get("/user", function (req, res) {
  res.json({ user: user});
}   
);

app.get("/seleccion", function (req, res) {
  res.json({seleccion: selec});
}   
);



// servidor
app.listen(4000, () => {
  console.log('Server is running on port 4000');
});